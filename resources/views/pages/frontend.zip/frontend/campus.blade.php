@extends('welcome')
@section('title')
{{'@All Derictors'}}
@endsection
@section('content')
 
   <!-- Start team Area -->
  <div class="our-team-area area-padding">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 60px">
          <div class="section-headline text-center">
            <h2>আমাদের ক্যাম্পাস সমূহঃ</h2>
          </div>
        </div>
      </div>
      <div class="form-outline mb-4">
          <form action="">
            <input type="search" placeholder="জেলা অনুযায়ী ক্যাম্পাস অনুসন্ধান করুন।" class="form-control" id="datatable-search-input">
            <label class="form-label" for="datatable-search-input">Search</label>
            
          </form>
      </div>
      <div class="row" >
        <div class="team-top">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <a  style="text-decoration: none;" href="{{route('single_campus')}}">
                    <div style="padding: 0px;" class="single-team-member">
                        <div class="team-content">
                            <p style="font-size: 20px; padding-left: 10px;"><b>L.M.A.F – ট্রেনিং সেন্টার, </b><b>Address: </b>বিমান বিল্ডিং, আমিরাবাদ , ঢাকা। <b>ফোনঃ</b> – ০১৯৬০-২৪১৮৫৪</p>                 
                        </div>
                    </div>
                </a>
            </div>  
          </div>
      </div>
    </div>
  </div>
  <!-- End Team Area -->

@endsection
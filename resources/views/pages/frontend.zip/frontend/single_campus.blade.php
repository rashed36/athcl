@extends('welcome')
@section('title')
{{'@All Derictors'}}
@endsection
@section('content')
 
   <!-- Start team Area -->
  <div class="our-team-area area-padding">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 60px">
          <div class="section-headline text-center">
            <h2>ঢাকা ক্যাম্পাস</h2>
          </div>
        </div>
      </div>
      <div class="row" >
        <div class="team-top">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <iframe src="https://maps.google.com/maps?q=%E0%A6%85%E0%A6%AE%E0%A7%83%E0%A6%A4%20%E0%A6%B2%E0%A6%BE%E0%A6%B2%20%E0%A6%A6%E0%A7%87%20%E0%A6%95%E0%A6%B2%E0%A7%87%E0%A6%9C%20%E0%A6%B8%E0%A6%82%E0%A6%B2%E0%A6%97%E0%A7%8D%E0%A6%A8,%20%E0%A6%A4%E0%A6%BE%E0%A6%B2%E0%A7%81%E0%A6%95%E0%A6%A6%E0%A6%BE%E0%A6%B0%20%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%E0%A6%B6%E0%A6%A8(%E0%A7%A9%E0%A7%9F%20%E0%A6%A4%E0%A6%B2%E0%A6%BE),%20%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A6%BE%E0%A6%A4%E0%A6%BE%E0%A6%B2%20%E0%A6%B0%E0%A7%8B%E0%A6%A1,%20%E0%A6%AC%E0%A6%B0%E0%A6%BF%E0%A6%B6%E0%A6%BE%E0%A6%B2%E0%A5%A4&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>  
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="well-middle">
                    <div class="single-well">
                        <h4>গণপ্রজাতন্ত্রী বাংলাদেশ সরকার কর্তৃক অনুমোদিত</h4>
                        <p>জনস্বাস্হ্য বিভাগ নিবন্ধন নং- 62/21 গভঃ রেজিঃ নং- C-175166/21</p>
                        <h5><b>আত-তাকওয়া হেলথ কেয়ার এন্ড ট্রেইনিং সেন্টার</b> </h5>
                        <p><b>প্রধান ক্যাম্পাস: </b> অমৃত লাল দে কলেজ সংলগ্ন, তালুকদার ম্যানশন(৩য় তলা), হাসপাতাল রোড, বরিশাল।</p>
                        <p style="font-size: 10px;"><b>জেলা ও উপজেলা ভিত্তিক শর্তসাপেক্ষে শাখা প্রদান করা  হবে।</b></p>
                        <h4 style="padding-top: 10px;"><b>আমাদের কিছু কথা</b></h4>
                      <p style="text-align: justify;" >
                        আমাদের দেশ ঘন বসতিপূর্ণ উন্নয়নশীল দেশ। এদেশের অধিকাংশ লোক গ্রামে বাস করে। 
                        অন্ন, বস্ত্র ও বাসস্থানের পাশাপাশি শিক্ষা ও চিকিৎসা প্রত্যেক মানুষের মৌলিক অধিকার।
                        গ্রামে এম.বি.বি.এস ডাক্তারের সংখ্যা অপ্রতুল হওয়ায় গ্রামের সাধারণ হতদরিদ্র মানুষ আধুনিক চিকিৎসা 
                        সেবা থেকে বঞ্চিত, এ ক্ষেত্রে পল্লী চিকিত্সকগণ গুরুত্বপূর্ণ ভূমিকা পালন করে আসছে। আমাদের দেশে 
                        শিক্ষিত বেকার যুবকের সংখ্যা দিন দিন বৃদ্ধি পাচ্ছে। অভিজ্ঞ চিকিৎসকদের 
                      </p>       
                        <a  style="font-weight: bold; color: blue; font-style: italic;"  href="{{route('about_details_page')}}">.....আরো পড়ুন</p></a>
                    </div>
                  </div>
                </div>
            </div>  
          </div>
      </div>
    </div>
  </div>
  <!-- End Team Area -->

@endsection